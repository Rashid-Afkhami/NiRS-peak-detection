% sys peak and reflected peak detection algorithm
clearvars
close all
% sample averaged s signal
load('supplementary_sample_channel')
zci = @(v) find(v(:).*circshift(v(:), [-1 0]) <= 0); 
% sampeling frequency
fs = 39.0625; 
for i1 = 1:length(my_s)
s = my_s{i1};   
[pks,locs] = findpeaks(s);
% skip zero channels
if isempty(pks)
    detected_peaks = [NaN NaN];
else
%   find the two diastolic peaks
    ind = find(pks == max(pks(locs < length(s)/2)));
    dia1 = [pks(ind(1)) locs(ind(1))];
    ind = find(pks == max(pks(locs > dia1(end,2) + .2)));
    dia2 = [pks(ind(1)) locs(ind(1))];
%   select inverted segment between the two diastolic peaks
    s = -s(dia1(end,2) : dia2(end,2));
%   second derivative and zci
    s2 = [diff(s,2) ; NaN ; NaN]; % second derivative of volume
    s2zci = zci(s2);
    [~,speak] = findpeaks(s);
    [~,s2npeak] = findpeaks(-s2);
    [~,s2ppeak] = findpeaks( s2);
%   continue if s2 has more than or equal to 4 zci 
    if length(s2zci) >= 4 
        s2zci = s2zci(1 : 4);
    if speak(1) > s2zci(2)
%   sys peak in inflection point
        sys_peak = s2zci(2);
    else
%       sys peak visible
        sys_peak = speak(1);
    end
%       reflected peak either a negative peak of s'' or visibale peak
        ref_peak_op1 = s2npeak(s2npeak > s2zci(3) & s2npeak < s2zci(4));
        ref_peak_op2 = speak(speak > s2zci(3) & speak < s2zci(4));
%       NaN if s'' is positive between third and fourth zero crossings
    if isempty(ref_peak_op1) 
        ref_peak = NaN; 
%       if no visible peak then select the s'' negative peak  
    elseif isempty(ref_peak_op2) 
        ref_peak = ref_peak_op1(1);
    else
        ref_peak = ref_peak_op2(1);
    end
        detected_peaks = [sys_peak ref_peak];
    else
        detected_peaks = [NaN NaN];
    end
    figure; plot(s,'b'); hold on; grid on
    plot(detected_peaks,s(detected_peaks),'ko')
    xlabel('Sample'); ylabel('Light Absorption')
end 
end 
